<div>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $transactionReports]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactionReports)]); ?>
     <?php $__env->slot('head'); ?> 
      <tr>
        <th>#</th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('id')" role="button" href="#">
            No. Transaksi
            <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('tracking_number')" role="button" href="#">
            No. Tracking
            <?php echo $__env->make('components.sort-icon', ['field' => 'tracking_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('sender_name')" role="button" href="#">
            Customer
            <?php echo $__env->make('components.sort-icon', ['field' => 'sender_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('total')" role="button" href="#">
            Total
            <?php echo $__env->make('components.sort-icon', ['field' => 'total'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
            Tanggal
            <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        
      </tr>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('body'); ?> 
      <?php $__currentLoopData = $transactionReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr x-data="window.__controller.dataTableController(<?php echo e($row->id); ?>)">
        <td><?php echo e($loop->iteration); ?></td>
        <td><a href="<?php echo e(route('invoice.view', $row->id)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($row->id); ?></strong></a></td>
        <td><a href="<?php echo e(route('tracking.view', $row->tracking_number)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($row->tracking_number); ?></strong></a></td>
        <td>
          <?php echo e($row->sender_name); ?> <br />
          <small><?php echo e($row->sender_address); ?></small> <br />
          <small><?php echo e($row->sender_phone); ?></small>
        </td>
        
        <td>Rp. <?php echo e(number_format($row->total)); ?></td>
        <td><?php echo e($row->created_at->format('d M Y H:i')); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
   <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/table/report-transaction.blade.php ENDPATH**/ ?>