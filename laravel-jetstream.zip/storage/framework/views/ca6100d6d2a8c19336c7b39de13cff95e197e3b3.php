<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>

  <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('css/tailwind.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

  <!-- Scripts -->
  <script defer src="<?php echo e(asset('vendor/alpine.js')); ?>"></script>
</head>
<body>
  <div class="font-sans text-gray-900 antialiased">
    <?php echo e($slot); ?>

  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/layouts/guest.blade.php ENDPATH**/ ?>