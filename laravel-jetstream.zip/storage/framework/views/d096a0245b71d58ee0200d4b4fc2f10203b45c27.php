<?php
$user = auth()->user();
?>
<div class="main-sidebar">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="<?php echo e(route('dashboard')); ?>">
        <img class="d-inline-block" width="32px" height="30.61px" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
      </a>
    </div>
    <ul class="sidebar-menu">
      <li class="menu-header">Dashboard Courier</li>
      <li class="<?php echo e(Request::routeIs('home') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i><span>Home</span></a>
      </li>
      <li class="<?php echo e(Request::routeIs('tracking') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('tracking')); ?>"><i class="fas fa-tachometer-alt"></i><span>Daftar
            Pengiriman</span></a>
      </li>
    </ul>
  </aside>
</div>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/components/user-sidebar.blade.php ENDPATH**/ ?>