 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header_content'); ?> 
    <h1>Dashboard</h1>
    <div class="section-header-breadcrumb">
      <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
      
      
    </div>
   <?php $__env->endSlot(); ?>

  <div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="far fa-address-card"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4>Total Kurir</h4>
          </div>
          <div class="card-body">
            <?php echo e($user); ?>

          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-danger">
          <i class="far fa-map"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4>Total Expedisi</h4>
          </div>
          <div class="card-body">
            <?php echo e($expedition); ?>

          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-warning">
          <i class="far fa-chart-bar"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4>Total Transaksi</h4>
          </div>
          <div class="card-body">
            <?php echo e($transaction); ?>

          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-success">
          <i class="fas fa-user-friends"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4>Pengunjung</h4>
          </div>
          <div class="card-body">
            <?php echo e($visitor); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-charts', [])->html();
} elseif ($_instance->childHasBeenRendered('2tJe0mT')) {
    $componentId = $_instance->getRenderedChildComponentId('2tJe0mT');
    $componentTag = $_instance->getRenderedChildComponentTagName('2tJe0mT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2tJe0mT');
} else {
    $response = \Livewire\Livewire::mount('show-charts', []);
    $html = $response->html();
    $_instance->logRenderedChild('2tJe0mT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/dashboard.blade.php ENDPATH**/ ?>