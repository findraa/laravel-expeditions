<?php $__env->startSection('content-header'); ?>
<div class="container">
  <div class="row mb-2">
    <div class="col-sm-6">
      <h1 class="m-0 text-dark"><?php echo e(__('Resi Pengiriman')); ?></h1>
    </div><!-- /.col -->
    <div class="col-sm-6">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item"><a href="/">Resi</a></li>
        <li class="breadcrumb-item active">Detail Resi</li>
      </ol>
    </div><!-- /.col -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-12">
      <!-- Main content -->
      <div class="invoice p-3 mb-3">
        <!-- title row -->
        <div class="row">
          <div class="col-12">
            <h4>
              <i class="fas fa-globe"></i> Ekspedisi Anugrah Indah.
              <small class="float-right">Tanggal: <?php echo e($transaction->created_at->format('d/m/Y')); ?></small>
            </h4>
          </div>
          <!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row invoice-info">
          <div class="col-sm-4 invoice-col">
            <br>Pengirim:
            <address>
              <strong><?php echo e(ucfirst($transaction->sender_name)); ?>.</strong><br>
              <?php echo e(Str::upper($transaction->sender_address)); ?><br>
              Makassar, Sulawesi-Selatan. <br>
              No. Telp: <?php echo e($transaction->sender_phone); ?>

            </address>
          </div>
          <!-- /.col -->
          <div class="col-sm-4 invoice-col">
            <br>Penerima:
            <address>
              <strong><?php echo e(ucfirst($transaction->reciver_name)); ?>.</strong><br>
              <?php echo e(Str::upper($transaction->reciver_address)); ?> <br>
              <?php echo e($transaction->city->name); ?>,
              <?php echo e($transaction->city->postal_code); ?>.
              <?php echo e($transaction->city->province->name); ?>. <br>
              No. Telp: <?php echo e($transaction->reciver_phone); ?>

            </address>
          </div>
          <!-- /.col -->
          <div class="col-sm-4 invoice-col">
            <b>Tracking #<?php echo e($transaction->tracking_number); ?></b><br>
            <br>
            <b>No. Pengiriman:</b> <?php echo e($transaction->id); ?><br>
            <b>Tanggal:</b> <?php echo e($transaction->created_at->format('d M Y H:i')); ?><br>
            <b>Status:</b> Dikonfirmasi<br>
            <b>Kurir:</b> <?php echo e($transaction->user->name); ?> <br>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- Table row -->
        <div class="row">
          <div class="col-12 table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Nama Barang</th>
                  <th>Qty</th>
                  <th>Berat</th>
                  
                  <th>Subtotal</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($row->item_name); ?></td>
                  <td><?php echo e($row->qty); ?></td>
                  <td><?php echo e($row->weight); ?> <?php echo e($row->area->weight); ?></td>
                  
                  <td>Rp. <?php echo e(number_format($row->subtotal)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <div class="row">
          <!-- accepted payments column -->
          <div class="col-6">
            <p class="lead">QR Code Transaksi:</p>

            <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
              <td><img src="data:image/png;base64, <?php echo $transaction->getQrcode($transaction->id); ?> ">
            </p>
          </div>
          <!-- /.col -->
          <div class="col-6">
            

            <div class="table-responsive">
              <table class="table">
                <tr>
                  <th style="width:50%">Subtotal:</th>
                  <td>Rp. <?php echo e(number_format($transaction->total)); ?></td>
                </tr>
                
                <tr>
                  <th>Potongan:</th>
                  <td>-</td>
                </tr>
                <tr>
                  <th>Total:</th>
                  <td>Rp. <?php echo e(number_format($transaction->total)); ?></td>
                </tr>
              </table>
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-12">
            
            <a type="button" href="<?php echo e(route('invoice.print', $transaction->id)); ?>" target="_blank"
              class="btn btn-primary float-right" style="margin-right: 5px;">
              <i class="fas fa-download"></i> Print
            </a>
          </div>
        </div>
      </div>
      <!-- /.invoice -->
    </div><!-- /.col -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/front/show-shipping.blade.php ENDPATH**/ ?>