<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Transaksi PDF</title>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

  <!-- Main Content -->
  <div class="main-content">
    <section class="section">
      <div class="section-body">
        <div class="invoice">
          <div class="invoice-print">
            <div class="row">
              <div class="col-lg-12">
                <p class="invoice-number text-right">Tanggal Cetak: <?php
                  echo date('d M Y')
                  ?></p>
                <div class="invoice-title text-center">
                  <h3>Laporan Transaksi</h3>
                  <hr>
                </div>
              </div>
            </div>

            <div class="row mt-4">
              <div class="col-md-12">
                <div class="table-responsive">
                  <table class="table table-striped table-hover table-md">
                    <thead>
                      <tr>
                        <th data-width="50">#</th>
                        <th>Pelanggan</th>
                        <th class="text-center">No. Transaksi</th>
                        <th class="text-center">Tanggal</th>
                        <th data-width="100" class="text-right">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $total = 0; ?>
                      <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($row->sender_name); ?><br>
                          Telp: <?php echo e($row->sender_phone); ?><br>
                          Alamat: <?php echo e($row->sender_address); ?></td>
                        <td class="text-center"><?php echo e($row->id); ?></td>
                        <td class="text-center"><?php echo e($row->created_at->format('d-m-Y')); ?></td>
                        <td class="text-right">Rp. <?php echo e(number_format($row->total)); ?></td>
                      </tr>
                      <?php $total += $row->total ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td colspan="5" class="text-center">Tidak ada data</td>
                      </tr>
                      <?php endif; ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colspan="4" class="text-left"><strong>Total</strong></td>
                        <td class="text-right"><strong>Rp. <?php echo e(number_format($total)); ?></strong></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/report/transaction_pdf.blade.php ENDPATH**/ ?>