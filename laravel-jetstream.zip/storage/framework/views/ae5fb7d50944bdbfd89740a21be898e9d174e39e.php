<div>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $users]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users)]); ?>
     <?php $__env->slot('head'); ?> 
      <tr>
        <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
            ID
            <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('name')" role="button" href="#">
            Nama
            <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('email')" role="button" href="#">
            Email
            <?php echo $__env->make('components.sort-icon', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('phone_number')" role="button" href="#">
            Telp
            <?php echo $__env->make('components.sort-icon', ['field' => 'phone_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
            Tanggal Dibuat
            <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('role')" role="button" href="#">
            Role
            <?php echo $__env->make('components.sort-icon', ['field' => 'role'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th>Action</th>
      </tr>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('body'); ?> 
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr x-data="window.__controller.dataTableController(<?php echo e($user->id); ?>)">
        <td><?php echo e($user->id); ?></td>
        <td><a href="#" class="font-weight-600"><img src="<?php echo e($user->profile_photo_url); ?>" alt="<?php echo e($user->name); ?>"
              width="30" class="rounded-circle mr-1"><?php echo e($user->name); ?></a></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->phone_number); ?></td>
        <td><?php echo e($user->created_at->format('d M Y')); ?></td>
        <td><?php echo $user->role_label; ?>

        </td>
        <td class="whitespace-no-wrap row-action--icon">
          <a role="button" href="/user/edit/<?php echo e($user->id); ?>" class="mr-3"><i class="fa fa-16px fa-pen"></i></a>
          <a role="button" x-on:click.prevent="deleteItem" href="#"><i class="fa fa-16px fa-trash text-red-500"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
   <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/table/user.blade.php ENDPATH**/ ?>