<div>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $transactions]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactions)]); ?>
     <?php $__env->slot('head'); ?> 
      <tr>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('id')" role="button" href="#">
            ID
            <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('tracking_number')" role="button" href="#">
            Tracking
            <?php echo $__env->make('components.sort-icon', ['field' => 'tracking_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('sender_name')" role="button" href="#">
            Pengirim
            <?php echo $__env->make('components.sort-icon', ['field' => 'sender_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('name')" role="button" href="#">
            Tujuan
            <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('total')" role="button" href="#">
            Total
            <?php echo $__env->make('components.sort-icon', ['field' => 'total'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
            Tanggal
            <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('status')" role="button" href="#">
            Status
            <?php echo $__env->make('components.sort-icon', ['field' => 'status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        
        <th>Action</th>
      </tr>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('body'); ?> 
      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr x-data="window.__controller.dataTableController(<?php echo e($transaction->id); ?>)">
        <td><a href="<?php echo e(route('invoice.view', $transaction->id)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($transaction->id); ?></strong></a></td>
        <td><a href="<?php echo e(route('tracking.view', $transaction->tracking_number)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($transaction->tracking_number); ?></strong></a></td>
        <td><?php echo e($transaction->sender_name); ?></td>
        <td><?php echo e($transaction->city->name); ?></td>
        <td>Rp. <?php echo e(number_format($transaction->total)); ?></td>
        <td><?php echo e($transaction->created_at->format('d M Y')); ?></td>
        <td><?php echo $transaction->status_label; ?></td>
        
        <td>
          
          <?php if($transaction->status != 4): ?>
          <button role="button" wire:click="$emit('updateItem', <?php echo e($transaction->id); ?>)" type="button"
            class="btn btn-primary btn-sm">Update
          </button>
          
          <?php endif; ?>
          
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
   <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('livewire:load', function () {
        window.livewire.find('<?php echo e($_instance->id); ?>').on('updateItem', id => {
            Swal.fire({
            title: 'Update status transaksi?',
            text: "Anda tidak akan dapat mengembalikan ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya!',
            cancelButtonText: 'Tidak, batal!'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                    window.livewire.find('<?php echo e($_instance->id); ?>').call('updateItem',id)

                    Swal.fire(
                        'Success!',
                        'Status transaksi berhasil diupdate.',
                        'success'
                    )
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                        'Cancelled',
                        'Proses update dibatalkan!',
                        'error'
                    )
                }
            });
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/table/transaction.blade.php ENDPATH**/ ?>