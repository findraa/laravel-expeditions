<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('adminlte/css/adminlte.min.css')); ?>">

  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <script src="https://kit.fontawesome.com/6f65dcd7f8.js" crossorigin="anonymous"></script>

  <?php echo \Livewire\Livewire::styles(); ?>


  <!-- Scripts -->
  <script defer src="<?php echo e(asset('vendor/alpine.js')); ?>"></script>
</head>
<body class="hold-transition layout-top-nav">

  <div class="wrapper">
    <!-- Navbar -->
    <?php echo $__env->make('components.navmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <?php echo $__env->yieldContent('content-header'); ?>
      </div>
      <!-- /.content-header -->
      <!-- Main content -->
      <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    <footer class="main-footer">
      <!-- To the right -->
      <div class="float-right d-none d-sm-inline">
        <b>Ver</b> 1.0.0
      </div>
      <!-- Default to the left -->
      <strong>&copy; <script>
          document.write(new Date().getFullYear());
        </script> <a href="https://adminlte.io">Anugrah Indah</a>.</strong>
    </footer>
  </div>
  <!-- REQUIRED SCRIPTS -->

  <!-- jQuery -->
  <script src="<?php echo e(asset('adminlte/vendor/jquery/jquery.min.js')); ?>"></script>
  <!-- Bootstrap 4 -->
  <script src="<?php echo e(asset('adminlte/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <!-- AdminLTE App -->
  <script src="<?php echo e(asset('adminlte/js/adminlte.min.js')); ?>"></script>

  <?php echo \Livewire\Livewire::scripts(); ?>


  <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
  <?php if(isset($script)): ?>
  <?php echo e($script); ?>

  <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/layouts/front.blade.php ENDPATH**/ ?>