<div>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $trackings]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trackings)]); ?>
     <?php $__env->slot('head'); ?> 
      <tr>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('id')" role="button" href="#">
            ID
            <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('tracking_number')" role="button" href="#">
            Tracking
            <?php echo $__env->make('components.sort-icon', ['field' => 'tracking_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('reciver_name')" role="button" href="#">
            Penerima
            <?php echo $__env->make('components.sort-icon', ['field' => 'reciver_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('name')" role="button" href="#">
            Tujuan
            <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
            Tanggal
            <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th class="whitespace-no-wrap"><a wire:click.prevent="sortBy('status')" role="button" href="#">
            Status
            <?php echo $__env->make('components.sort-icon', ['field' => 'status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        
        <th>Action</th>
      </tr>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('body'); ?> 
      <?php $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr x-data="window.__controller.dataTableController(<?php echo e($row->id); ?>)">
        <td><a href="<?php echo e(route('invoice.view', $row->id)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($row->id); ?></strong></a></td>
        <td><a href="<?php echo e(route('tracking.view', $row->tracking_number)); ?>" target="_blank"><strong
              class="text-primary"><?php echo e($row->tracking_number); ?></strong></a></td>
        <td>
          <?php echo e(ucfirst($row->reciver_name)); ?><br />
          <small><?php echo e($row->reciver_phone); ?></small>
        </td>
        <td> <?php echo e($row->city->name); ?> <br>
          <small><?php echo e($row->city->province->name); ?>, <?php echo e($row->city->postal_code); ?></small></td>
        <td><?php echo e($row->created_at->format('d M Y H:i')); ?></td>
        <td><?php echo $row->status_label; ?></td>
        
        <td align="center">
          
          <?php if($row->status != 4): ?>
          <button role="button" wire:click="$emit('updateItem', <?php echo e($row->id); ?>)" type="button"
            class="btn btn-primary btn-sm icon-left">Update
          </button>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
   <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('livewire:load', function () {
        window.livewire.find('<?php echo e($_instance->id); ?>').on('updateItem', id => {
            Swal.fire({
            title: 'Update status transaksi?',
            text: "Anda tidak akan dapat mengembalikan ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya!',
            cancelButtonText: 'Tidak, batal!'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                    window.livewire.find('<?php echo e($_instance->id); ?>').call('updateItem',id)

                    Swal.fire(
                        'Success!',
                        'Status transaksi berhasil diupdate.',
                        'success'
                    )
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                        'Cancelled',
                        'Proses update dibatalkan!',
                        'error'
                    )
                }
            });
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/table/tracking.blade.php ENDPATH**/ ?>