<div>
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $expeditions]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($expeditions)]); ?>
     <?php $__env->slot('head'); ?> 
      <tr>
        <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
            ID
            <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
            Nama
            <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
            Tanggal Dibuat
            <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th><a wire:click.prevent="sortBy('updated_at')" role="button" href="#">
            Tanggal Diupdate
            <?php echo $__env->make('components.sort-icon', ['field' => 'updated_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a></th>
        <th>Action</th>
      </tr>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('body'); ?> 
      <?php $__currentLoopData = $expeditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expedition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr x-data="window.__controller.dataTableController(<?php echo e($expedition->id); ?>)">
        <td><?php echo e($expedition->id); ?></td>
        <td><?php echo e($expedition->name); ?></td>
        <td><?php echo e($expedition->created_at->format('d M Y H:i')); ?></td>
        <td><?php echo e($expedition->updated_at->format('d M Y H:i')); ?></td>
        <td class="whitespace-no-wrap row-action--icon">
          <a role="button" href="/expedition/edit/<?php echo e($expedition->id); ?>" class="mr-3"><i
              class="fa fa-16px fa-pen"></i></a>
          <a role="button" x-on:click.prevent="deleteItem" href="#"><i class="fa fa-16px fa-trash text-red-500"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
   <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/table/expedition.blade.php ENDPATH**/ ?>