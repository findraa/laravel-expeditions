 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header_content'); ?> 
    <h1><?php echo e(__('Data Transaksi')); ?></h1>

    <div class="section-header-breadcrumb">
      <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
      <div class="breadcrumb-item"><a href="#">User</a></div>
      <div class="breadcrumb-item"><a href="<?php echo e(route('transaction')); ?>">Data Transaksi</a></div>
    </div>
   <?php $__env->endSlot(); ?>

  <div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('table.main', ['name' => 'transaction','model' => $transaction])->html();
} elseif ($_instance->childHasBeenRendered('ncwXsNy')) {
    $componentId = $_instance->getRenderedChildComponentId('ncwXsNy');
    $componentTag = $_instance->getRenderedChildComponentTagName('ncwXsNy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ncwXsNy');
} else {
    $response = \Livewire\Livewire::mount('table.main', ['name' => 'transaction','model' => $transaction]);
    $html = $response->html();
    $_instance->logRenderedChild('ncwXsNy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/transaction/transaction-data.blade.php ENDPATH**/ ?>