 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header_content'); ?> 
    <h1>Data Tracking</h1>
    <div class="section-header-breadcrumb">
      <div class="breadcrumb-item active"><a href="#">Home</a></div>
      <div class="breadcrumb-item"><a href="#">Data Tracking</a></div>
      
    </div>
   <?php $__env->endSlot(); ?>

  <div class="section-body">
    <h2 class="section-title">No. Tracking #<?php echo e($transaction->tracking_number); ?> - Tujuan <?php echo e($transaction->city->name); ?>

    </h2>
    <div class="row">
      <div class="col-12">
        <div class="activities">

          <?php if(!is_null($transaction->accepted_at)): ?>
          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-check"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($transaction->accepted_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>Pesanan telah diterima oleh <?php echo e($transaction->reciver_name); ?>".</p>
            </div>
          </div>
          <?php endif; ?>

          <?php if(!is_null($transaction->finish_at)): ?>
          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($transaction->finish_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>Pesanan telah sampai di drop point <?php echo e($transaction->city->name); ?>.</p>
            </div>
          </div>
          <?php endif; ?>

          <?php $__currentLoopData = $transaction->trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-shipping-fast"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($row->created_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>[<?php echo e($row->city->name); ?>] Pesanan sedang berada dalam perjalanan.</p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php if(!is_null($transaction->shipping_at)): ?>
          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-truck"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($transaction->shipping_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>[Makassar] Pesanan telah keluar dari gudang.</p>
            </div>
          </div>
          <?php endif; ?>

          <?php if(!is_null($transaction->process_at)): ?>
          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-truck-loading"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($transaction->process_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>Pesanan telah diproses dan akan segera di serahkan ke kurir.</p>
            </div>
          </div>
          <?php endif; ?>

          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
              <i class="fas fa-box"></i>
            </div>
            <div class="activity-detail">
              <div class="mb-2">
                <span class="bullet"></span>
                <span class="text-job text-primary"><?php echo e($transaction->created_at->format('d M H:i')); ?></span>
                <div class="float-right dropdown">
                  <a href="#" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                  <div class="dropdown-menu">
                    <div class="dropdown-title">Options</div>
                    <a href="#" class="dropdown-item has-icon"><i class="fas fa-list"></i> Detail</a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item has-icon text-danger"
                      data-confirm="Wait, wait, wait...|This action can't be undone. Want to take risks?"
                      data-confirm-text-yes="Yes, IDC"><i class="fas fa-trash-alt"></i> Archive</a>
                  </div>
                </div>
              </div>
              <p>Pesanan telah diterima dan akan segera di proses.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/tracking/tracking-history.blade.php ENDPATH**/ ?>