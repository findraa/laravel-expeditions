<?php $__env->startSection('Lacak', 'nav-item active'); ?>
<?php $__env->startSection('Home', 'nav-item'); ?>
<?php $__env->startSection('Tarif', 'nav-item'); ?>
<?php $__env->startSection('Kontak', 'nav-item'); ?>

<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-wrap-2 mb-5" style="background-image: url('<?php echo e(asset('image/sea.gif')); ?>');"
  data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text align-items-end justify-content-start">
      <div class="col-md-12 ftco-animate text-center mb-5">
        <h1 class="mb-3 bread">LACAK KIRIMAN</h1>
        <div class="row d-flex justify-content-center">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
            <div class="row d-flex justify-content-center mt-4 mb-4">
              <div class="col-md-12">
                <form class="subscribe-form" method="get" action="<?php echo e(url('TampilLacak')); ?>">
                  <div class="form-group d-flex">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control text-center" name="cari" placeholder="Masukkan No. Tracking">
                    <input type="submit" value="TRACKING" class="submit px-3">
                    
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<section class="ftco-section bg-light">
  <div class="container">
    <div class="row">

      <div class=" col-lg-8 mb-5 ">

        <form action="<?php echo e(url('CekTarif')); ?>" method="post" class="p-5 bg-white">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="form-row">
              <div class="col col-2">Nama Expedisi</div>
              <div class="col">
                <select name="expedisi" class="form-control" id="expedisi">
                  <option selected="selected" disabled="disabled"></option>
                  
                </select>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <div class="form-group">
                <label for="exampleFormControlInput1">Berat Barang</label>
                <input type="number" name="berat" value="1" class="form-control" id="berat">
              </div>
            </div>
            <div class="col">
              <div class="form-group">
                <label for="exampleFormControlSelect1">Satuan</label>
                <select class="form-control" name="satuan" id="satuan">
                  <option selected="selected" disabled="disabled"></option>
                </select>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col">
                <label for="dari">Dari</label>
                <input type="text" name="dari" disabled value="Makassar" id="dari" class="form-control">
              </div>
              <div class="col">
                <label for="dari">Tujuan</label>
                <select name="tujuan" class="form-control" id="tujuan">
                  <option value="Ambon">Ambon</option>
                </select>
              </div>
            </div>
          </div>
          <div class="row form-group">
            <div class="col-md-12 mt-3">
              <input type="button" id="hitung" value="CEK TARIF" class="btn btn-primary  btn-lg  py-2 px-5">
            </div>
          </div>
          <h1 class="text-center" id="harga"></h1>
        </form>
      </div>



      <div class="col-lg-4">
        <div class="p-4 mb-3 bg-white">
          <h3 class="h5 text-black mb-3">Contact Info</h3>
          <p class="mb-0 font-weight-bold">Alamat</p>
          <p class="mb-4">aaaa</p>
          <p class="mb-0 font-weight-bold">Phone</p>
          <p class="mb-4">000000</p>
        </div>
      </div>
    </div>

  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/front/tracking.blade.php ENDPATH**/ ?>