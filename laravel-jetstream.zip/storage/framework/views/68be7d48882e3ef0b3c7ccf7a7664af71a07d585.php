<?php $__env->startSection('content-header'); ?>
<div class="container">
  <div class="row mb-2">
    <div class="col-sm-6">
      <h1 class="m-0 text-dark">No. Tracking #<?php echo e($tracking->tracking_number); ?></h1>
    </div><!-- /.col -->
    <div class="col-sm-6">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item"><a href="/">Tracking</a></li>
        <li class="breadcrumb-item active">Status Tracking</li>
      </ol>
    </div><!-- /.col -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

  <!-- Timelime example  -->
  <div class="row">
    <div class="col-md-12">
      <!-- The time line -->
      <div class="timeline">
        <!-- timeline time label -->
        
        <!-- /.timeline-label -->
        <?php if(!is_null($tracking->accepted_at)): ?>
        <div>
          <i class="fas fa-truck bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->accepted_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              Pesanan telah diterima oleh <?php echo e($tracking->reciver_name); ?>".
            </div>
          </div>
        </div>
        <?php endif; ?>

        <?php if(!is_null($tracking->finish_at)): ?>
        <div>
          <i class="fas fa-truck bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->finish_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              Pesanan telah sampai di drop point <?php echo e($tracking->city->name); ?>.
            </div>
          </div>
        </div>
        <?php endif; ?>

        <?php $__currentLoopData = $tracking->trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- timeline item -->
        <div>
          <i class="fas fa-truck bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->created_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              [<?php echo e($row->city->name); ?>] Pesanan sedang berada dalam perjalanan.
            </div>
          </div>
        </div>
        <!-- END timeline item -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(!is_null($tracking->shipping_at)): ?>
        <!-- timeline item -->
        <div>
          <i class="fas fa-truck bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->shipping_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              [Makassar] Pesanan telah keluar dari gudang.
            </div>
          </div>
        </div>
        <!-- END timeline item -->
        <?php endif; ?>

        <?php if(!is_null($tracking->process_at)): ?>
        <!-- timeline item -->
        <div>
          <i class="fas fa-truck-loading bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->process_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              Pesanan telah diproses dan akan segera di serahkan ke kurir.
            </div>
          </div>
        </div>
        <!-- END timeline item -->
        <?php endif; ?>

        <!-- timeline item -->
        <div>
          <i class="fas fa-box bg-blue"></i>
          <div class="timeline-item">
            <span class="time"><i class="fas fa-clock"></i> <?php echo e($tracking->created_at->format('d M H:i')); ?></span>
            <div class="timeline-body">
              Pesanan telah diterima dan akan segera di proses.
            </div>
          </div>
        </div>
        <!-- END timeline item -->

      </div>
    </div>
    <!-- /.col -->
  </div>
</div>
<!-- /.timeline -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/front/show-tracking.blade.php ENDPATH**/ ?>