 <?php if (isset($component)) { $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontLayout::class, []); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header_content'); ?> 
    <div class="container">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark"><?php echo e(__('Resi Pengiriman')); ?></h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active">Cek Resi</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
   <?php $__env->endSlot(); ?>

  <div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title">Cek Resi Pengiriman</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form class="form-horizontal" wire:submit.prevent="submit">
              <div class="card-body">
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-3 col-form-label">Masukkan No. Resi/Tracking</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="inputEmail3" wire:model="transactionId"
                      placeholder="Masukkan No. Resi/Tracking">
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <button type="submit" class="btn btn-primary float-right">Submit</button>
              </div>
              <!-- /.card-footer -->
            </form>
          </div>
          <!-- /.card -->

          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.show-shipping')->html();
} elseif ($_instance->childHasBeenRendered('WEdKQW9')) {
    $componentId = $_instance->getRenderedChildComponentId('WEdKQW9');
    $componentTag = $_instance->getRenderedChildComponentTagName('WEdKQW9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WEdKQW9');
} else {
    $response = \Livewire\Livewire::mount('front.show-shipping');
    $html = $response->html();
    $_instance->logRenderedChild('WEdKQW9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
      </div>
    </div>
  </div>
 <?php if (isset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a)): ?>
<?php $component = $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a; ?>
<?php unset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/livewire/front/shipping.blade.php ENDPATH**/ ?>