<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">

  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('front/css/open-iconic-bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.theme.default.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/magnific-popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/aos.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/ionicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('front/css/style-user.css')); ?>">
  <script src="https://kit.fontawesome.com/6f65dcd7f8.js" crossorigin="anonymous"></script>

  <!-- AdminLTE css -->
  <link rel="stylesheet" href="<?php echo e(asset('front/js/adminlte.min.css')); ?>">

  <script src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-md-4">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('image/logo.png')); ?>" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
        aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="<?php echo $__env->yieldContent('Home'); ?>"><a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a></li>
          <li class="<?php echo $__env->yieldContent('Lacak'); ?>"><a href="<?php echo e(url('/tracking')); ?>" class="nav-link">Lacak</a></li>
          <li class="<?php echo $__env->yieldContent('Tarif'); ?>"><a href="<?php echo e(url('/tarif')); ?>" class="nav-link">Cek Tarif</a></li>
          
          <li class="<?php echo $__env->yieldContent('Kontak'); ?>"><a href="<?php echo e(url('/kontak')); ?>" class="nav-link">Kontak Kami</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- END nav -->

  <?php echo $__env->yieldContent('content'); ?>

  <footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Tentang kami</h2>
            <h2 class="ftco-heading-2">Anugrah Indah Ekspedisi</h2>
            <p>Pengiriman cepat dan aman <br> via angkutan darat dan laut, Tarif ekspedisi murah</p>
            
          </div>
        </div>
        <div class="col-md">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Lokasi</h2>
            
            
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d1986.9467338039995!2d119.41079067931726!3d-5.120865167722134!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m1!1m0!5e0!3m2!1sen!2sid!4v1616203063997!5m2!1sen!2sid"
              width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            
          </div>
        </div>
        
        <div class="col-md">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Hubungi kami</h2>
            <div class="block-23 mb-3">
              <ul>
                
                <li><span class="icon icon-map-marker"></span><span class="text">Jl. Kalimantan</span>
                </li>
                <li><span class="icon icon-phone"></span><span class="text">085298907939</span></a>
                </li>
                <li><span class="icon icon-envelope"></span><span class="text">info@anugrahindah.com</span></a></li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">

          <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>
              document.write(new Date().getFullYear());
            </script> All rights reserved | <i class="icon-heart text-danger" aria-hidden="true"></i> by <a
              href="https://colorlib.com" target="_blank">Anugrah Indah</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
        </div>
      </div>
    </div>
  </footer>



  <!-- loader -->
  

  <script src="<?php echo e(asset('front/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.easing.1.3.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.stellar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.animateNumber.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/scrollax.min.js')); ?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false">
  </script>
  <!-- AdminLTE App -->
  <script src="<?php echo e(asset('front/js/adminlte.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('front/js/main-user.js')); ?>"></script>
  <script>
    $("ul li").on("click", function () {
          $("li").removeClass("active");
          $(this).addClass("active");
      });
  </script>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/layouts/user.blade.php ENDPATH**/ ?>