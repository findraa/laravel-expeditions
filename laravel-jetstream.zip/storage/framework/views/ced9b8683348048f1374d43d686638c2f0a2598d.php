<?php $__env->startSection('content-header'); ?>
<div class="container">
  <div class="row mb-2">
    <div class="col-sm-6">
      <h1 class="m-0 text-dark">Konfirmasi</h1>
    </div><!-- /.col -->
    <div class="col-sm-6">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="/">Konfirmasi Pesanan</a></li>
      </ol>
    </div><!-- /.col -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if($order->status == 4): ?>
  <div class="error-page">
    <h2 class="headline text-success">#<?php echo e($order->id); ?></h2>

    <div class="error-content">
      <h3><i class="fas fa-check text-success"></i> Anda telah mengkonfirmasi penerimaan barang.</h3>

      <p>
        Terimah kasih telah menggunakan layanan ekspedisi anugrah indah.
        Jika anda mempunyai saran dan kritik, silahkan hubungi kami melalui pesan :)
      </p>

      
    </div>
  </div>
  <!-- /.error-page -->
  <?php endif; ?>
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/pages/front/confirm.blade.php ENDPATH**/ ?>