<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">

  <?php if(isset($meta)): ?>
  <?php echo e($meta); ?>

  <?php endif; ?>

  <!-- Styles -->
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@400;600;700&family=Open+Sans&display=swap">

  <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/tailwind.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('stisla/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('stisla/css/components.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/notyf/notyf.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

  <script src="https://kit.fontawesome.com/6f65dcd7f8.js" crossorigin="anonymous"></script>

  <?php echo \Livewire\Livewire::styles(); ?>


  <!-- Scripts -->
  <script defer src="<?php echo e(asset('vendor/alpine.js')); ?>"></script>
</head>
<body class="antialiased">
  <div id="app">
    <div class="main-wrapper">
      <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php if(auth()->user()->role == '0'): ?>
      <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>

      <?php if(auth()->user()->role == '1'): ?>
      <?php echo $__env->make('components.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <?php if(isset($header_content)): ?>
            <?php echo e($header_content); ?>

            <?php else: ?>
            <?php echo e(__('Profile')); ?>

            <?php endif; ?>
          </div>

          <div class="section-body">
            <?php echo e($slot); ?>

          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; <script>
            document.write(new Date().getFullYear());
          </script> <a href="/">Anugrah Indah</a>.
        </div>
        <div class="footer-right">
          1.0.0
        </div>
      </footer>
    </div>
  </div>

  <?php echo $__env->yieldPushContent('modals'); ?>

  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('stisla/js/modules/jquery.min.js')); ?>"></script>
  <script defer async src="<?php echo e(asset('stisla/js/modules/popper.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
  </script>
  <script defer async src="<?php echo e(asset('stisla/js/modules/tooltip.js')); ?>"></script>
  <script src="<?php echo e(asset('stisla/js/modules/bootstrap.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('stisla/js/modules/jquery.nicescroll.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('stisla/js/modules/moment.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('stisla/js/modules/marked.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('vendor/notyf/notyf.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('vendor/sweetalert/sweetalert.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('stisla/js/modules/chart.min.js')); ?>"></script>
  <script defer src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>

  <script src="<?php echo e(asset('stisla/js/stisla.js')); ?>"></script>
  <script src="<?php echo e(asset('stisla/js/scripts.js')); ?>"></script>

  <?php echo \Livewire\Livewire::scripts(); ?>

  <script src="http://127.0.0.1:8000/vendor/livewire-charts/app.js"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-jetstream\resources\views/layouts/app.blade.php ENDPATH**/ ?>