<?php return array (
  'create-area' => 'App\\Http\\Livewire\\CreateArea',
  'create-detail-transaction' => 'App\\Http\\Livewire\\CreateDetailTransaction',
  'create-expedition' => 'App\\Http\\Livewire\\CreateExpedition',
  'create-message' => 'App\\Http\\Livewire\\CreateMessage',
  'create-tracking' => 'App\\Http\\Livewire\\CreateTracking',
  'create-transaction' => 'App\\Http\\Livewire\\CreateTransaction',
  'create-user' => 'App\\Http\\Livewire\\CreateUser',
  'show-charts' => 'App\\Http\\Livewire\\ShowCharts',
  'table.main' => 'App\\Http\\Livewire\\Table\\Main',
);